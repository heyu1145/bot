from discord.ext import tasks
import asyncio
@tasks.loop(minutes=1)
async def refresh_embeds():
    """Simple embed refresher"""
    # Assuming your data structure is: {guild_id: {channel_id: [message_ids]}}
    all_data = load_msg() or {}
    
    for guild_id_str, channels in all_data.items():
        guild = bot.get_guild(int(guild_id_str))
        await asyncio.sleep(0.3)
        if not guild:
            continue
        
        for channel_id_str, message_ids in channels.items():
            channel = guild.get_channel(int(channel_id_str))
            await asyncio.sleep(0.3)
            if not channel:
                continue
            
            for message_id in message_ids:
                try:
                    message = await channel.fetch_message(message_id)
                    await asyncio.sleep(0.3)
                    if message.embeds:
                        old_embed = message.embeds[0]
                        new_embed = old_embed.copy()
                        new_embed.description = str(load(guild_id_str))
                        new_embed.timestamp = discord.utils.utcnow()
                        
                        await message.edit(embed=new_embed)
                        
                except Exception as e:
                    print(f"Failed to refresh {message_id}: {e}")

@bot.event
async def on_ready():
    refresh_embeds.start()